from flask import Flask, render_template, redirect, url_for, request, session
from datetime import datetime
from db.dbhelper import getrecord, addrecord, getall, count_records, count_todays_attendance, updaterecord, deleterecord
import base64
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key_here' 
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0 

@app.route("/")
def index() -> str:
    return render_template("index.html")
    
@app.route("/check", methods=["GET"])
def check() -> str:
    idno: str = request.args.get("idno").strip()
    student_records = getrecord("students", idno=idno)
    
    found_student = None
    if student_records:
        found_student = dict(student_records[0])
        
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
        
        addrecord("attendance", idno=idno, date_time=timestamp)
        
        found_student['date_time'] = timestamp 

    return render_template("attendance.html", student=found_student)

@app.route("/admin", methods=["GET", "POST"])
def admin_login():
    error = None
    
    if request.method == "POST":
        admin_email = request.form['email']
        password = request.form['password']
        
        admin_user = getrecord("admin", email=admin_email)

        if admin_user and admin_user[0]['password'] == password:
            session['logged_in'] = True
            session['username'] = admin_user[0]['email']
            return redirect(url_for('add_student')) 
        else:
            error = "Invalid Credentials. Please try again."
            
    return render_template("admin.html", error=error)
    
@app.route("/admin/logout")
def admin_logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route("/admin/view_student/<int:student_id>")
def view_student(student_id):
    if not session.get('logged_in'):
        return redirect(url_for('admin_login'))
    
    return redirect(url_for('add_student', edit_id=student_id))

@app.route("/admin/add_student", methods=["GET"])
def add_student():
    if not session.get('logged_in'):
        return redirect(url_for('admin_login'))
    
    message = None
    message_type = request.args.get('message_type')
    message_text = request.args.get('message_text')
    new_student_idno = request.args.get('new_student_idno')
    if message_type and message_text:
        message = (message_type, message_text)
        
    student_to_edit = None
    edit_student_id = request.args.get('edit_id') 
    if edit_student_id:
        record = getrecord("students", id=edit_student_id)
        if record:
            student_to_edit = dict(record[0]) 
        
    all_students_raw = getall("students")
    all_students = [dict(s) for s in all_students_raw]

    total_students = count_records("students")
    today_attendance = count_todays_attendance()

    return render_template("admin_add_student.html", 
                           message=message,
                           all_students=all_students, 
                           student_to_edit=student_to_edit,
                           new_student_idno=new_student_idno,
                           total_students=total_students,
                           today_attendance=today_attendance)


@app.route("/admin/confirm_student", methods=["POST"])
def confirm_student():
    if not session.get('logged_in'):
        return redirect(url_for('admin_login'))

    # CHECK FOR HIDDEN student_id (present if editing)
    student_id = request.form.get('student_id')
    idno = request.form['idno'].strip()
    lastname = request.form['lastname'].strip()
    firstname = request.form['firstname'].strip()
    course = request.form['course'].strip()
    level = request.form['level'].strip()
    image_data = request.form.get('image_data')

    if not (idno and lastname and image_data and course and level):
        msg = "Missing required student data or image snapshot."
        redirect_args = {'message_type': 'error', 'message_text': msg}
        if student_id:
            redirect_args['edit_id'] = student_id
        return redirect(url_for('add_student', **redirect_args))

    # ONLY check for ID existence if we are NOT updating an existing student
    if not student_id and getrecord("students", idno=idno):
        msg = f"Student with ID Number {idno} already exists. Cannot proceed."
        return redirect(url_for('add_student', message_type='error', message_text=msg))

    student_data = {
        'student_id': student_id, # PASS THE ID TO CONFIRMATION PAGE
        'idno': idno, 
        'lastname': lastname, 
        'firstname': firstname, 
        'course': course, 
        'level': level,
        'image_data': image_data 
    }
    
    return render_template("student_confirm.html", student=student_data)


@app.route("/admin/save_student", methods=["POST"])
def save_student():
    if not session.get('logged_in'):
        return redirect(url_for('admin_login'))
    
    # CHECK FOR HIDDEN student_id to determine INSERT or UPDATE
    student_id = request.form.get('student_id') 
    idno = request.form['idno'].strip()
    is_update = bool(student_id)

    data_to_save = {
        'idno': idno, 
        'lastname': request.form['lastname'].strip(), 
        'firstname': request.form['firstname'].strip(), 
        'course': request.form['course'].strip(), 
        'level': request.form['level'].strip()
    }
    image_data = request.form.get('image_data')
    
    redirect_args = {}
    if is_update:
        redirect_args['edit_id'] = student_id 

    if image_data and ',' in image_data:
        
        # 1. Delete old image if updating
        if is_update:
            old_record = getrecord("students", id=student_id)
            old_student_data = dict(old_record[0]) if old_record else {} 
            if old_student_data.get('image_path'):
                old_image_path = old_student_data['image_path']
                try:
                    full_old_path = os.path.join(app.root_path, 'static', old_image_path)
                    full_old_path = full_old_path.replace('/', os.sep)
                    if os.path.exists(full_old_path):
                        os.remove(full_old_path)
                except Exception as e:
                    print(f"Warning: Failed to delete old image file: {e}")
                
        # 2. Save new image
        try:
            filename_suffix = "_updated" if is_update else ""
            filename = f"{idno}_{datetime.now().strftime('%Y%m%d%H%M%S')}{filename_suffix}.JPEG" 
            new_image_path = os.path.join('images', filename) 
            static_dir = os.path.join(app.root_path, 'static')
            
            os.makedirs(os.path.join(static_dir, 'images'), exist_ok=True)
            save_path = os.path.join(static_dir, new_image_path)
            
            img_b64 = image_data.split(',')[1]
            img_decoded = base64.b64decode(img_b64)
            with open(save_path, "wb") as f:
                f.write(img_decoded)
            
            data_to_save['image_path'] = new_image_path.replace('\\', '/')
            
        except Exception as e:
            msg = f"Image save failed: {e}"
            redirect_args['message_type'] = 'error'
            redirect_args['message_text'] = msg
            return redirect(url_for('add_student', **redirect_args))
    else:
        # This occurs if the image data is lost, which is critical for both new and update
        msg = "Image snapshot data was lost during submission. Please take a new snapshot."
        redirect_args['message_type'] = 'error'
        redirect_args['message_text'] = msg
        return redirect(url_for('add_student', **redirect_args))


    # 3. Database operation: INSERT or UPDATE
    if is_update:
        # Call updaterecord to modify the existing student by ID
        success = updaterecord("students", where={'id': student_id}, updates=data_to_save)
        msg = f"Student ID {idno} updated successfully!"
    else:
        # Call addrecord for a new student
        success = addrecord("students", **data_to_save)
        msg = f"New Student {idno} saved successfully!"
    
    if success:
        redirect_args = {'message_type': 'success', 'message_text': msg}
        if not is_update:
            redirect_args['new_student_idno'] = idno
        return redirect(url_for('add_student', **redirect_args))
    else:
        # This catches the 'Database error: Could not save/update student.'
        msg = "Database error: Could not save/update student."
        redirect_args['message_type'] = 'error'
        redirect_args['message_text'] = msg
        return redirect(url_for('add_student', **redirect_args))


@app.route("/admin/delete_student/<int:student_id>", methods=["POST"])
def delete_student(student_id):
    if not session.get('logged_in'):
        return redirect(url_for('admin_login'))
    
    student_record = getrecord("students", id=student_id)
    success = False

    if student_record and student_record[0]:
        student_data = dict(student_record[0])
        image_path = student_data.get('image_path')
        
        success = deleterecord("students", id=student_id)
        
        if success:
            if image_path:
                full_image_path = os.path.join(app.root_path, 'static', image_path)
                full_image_path = full_image_path.replace('/', os.sep)

                try:
                    if os.path.exists(full_image_path):
                        os.remove(full_image_path)
                        msg = f"Student ID {student_data['idno']} and photo deleted successfully."
                    else:
                        msg = f"Student ID {student_data['idno']} deleted (photo file not found)."
                except Exception as e:
                    print(f"Error deleting image file: {e}")
                    msg = f"Student deleted, but failed to delete photo file: {e}"
            else:
                msg = f"Student ID {student_data['idno']} deleted successfully (no photo to delete)."
        else:
            msg = "Database error: Could not delete student."
    else:
        msg = "Error: Student record not found."

    return redirect(url_for('add_student', message_type='success' if success else 'error', message_text=msg))


@app.route("/admin/edit_admin/<int:admin_id>")
def edit_admin(admin_id):
    if not session.get('logged_in'): 
        return redirect(url_for('admin_login'))
    
    admin_record = getrecord("admin", id=admin_id)
    
    if not admin_record:
        return redirect(url_for('add_admin'))
    
    current_admins_raw = getall("admin")
    current_admins = [dict(a) for a in current_admins_raw]

    return render_template(
        "admin_add_admin.html", 
        message=None, 
        current_admins=current_admins,
        admin_to_edit=dict(admin_record[0])
    )

@app.route("/admin/add_admin", methods=["GET", "POST"])
def add_admin():
    if not session.get('logged_in'): 
        return redirect(url_for('admin_login'))
    
    message = None
    
    if request.method == "POST":
        admin_id = request.form.get('admin_id') 
        admin_email = request.form['email'].strip() 
        password = request.form['password'].strip()
        
        updates_data = {'email': admin_email}
        if password:
            updates_data['password'] = password
            
        if admin_id:
            existing_admin = getrecord("admin", email=admin_email)
            if existing_admin and existing_admin[0]['id'] != int(admin_id):
                 message = ("error", f"Email '{admin_email}' already used by another admin.")
            else:
                success = updaterecord("admin", where={'id': admin_id}, updates=updates_data) 
                
                if success:
                    message = ("success", f"Administrator '{admin_email}' updated successfully!")
                else:
                    message = ("error", "Database error: Could not update administrator.")
        
        else:
            if getrecord("admin", email=admin_email):
                message = ("error", f"Admin user with email '{admin_email}' already exists.")
            elif not password or len(password) < 6:
                message = ("error", "Password must be at least 6 characters.")
            else:
                success = addrecord("admin", email=admin_email, password=password)
                
                if success:
                    message = ("success", f"New Administrator '{admin_email}' added successfully!")
                else:
                    message = ("error", "Database error: Could not add administrator.")
    
    current_admins_raw = getall("admin")
    current_admins = [dict(a) for a in current_admins_raw]
        
    return render_template("admin_add_admin.html", message=message, current_admins=current_admins)


@app.route("/admin/delete_attendance/<int:record_id>", methods=["POST"])
def delete_attendance(record_id):
    if not session.get('logged_in'):
        return redirect(url_for('admin_login'))
    
    success = deleterecord("attendance", id=record_id)
    
    if success:
        message_text = "Attendance record deleted successfully."
        message_type = "success"
    else:
        message_text = "Error: Could not delete attendance record."
        message_type = "error"
        
    return redirect(url_for('view_attendance', message_type=message_type, message_text=message_text))


@app.route("/admin/attendance_log", methods=["GET"])
def view_attendance():
    if not session.get('logged_in'):
        return redirect(url_for('admin_login'))
    
    message = None
    message_type = request.args.get('message_type')
    message_text = request.args.get('message_text')
    if message_type and message_text:
        message = (message_type, message_text)
        
    selected_date = request.args.get('date')
    if not selected_date:
        selected_date = datetime.now().strftime("%Y-%m-%d")

    attendance_records_raw = getall("attendance")
    all_attendance_records = [dict(a) for a in attendance_records_raw]
    
    filtered_attendance_records = [
        record for record in all_attendance_records
        if record['date_time'].startswith(selected_date)
    ]

    all_students_raw = getall("students")
    student_map = {
        student['idno']: dict(student) 
        for student in all_students_raw
    }
    
    merged_attendance = []
    for record in filtered_attendance_records:
        student_idno = record['idno']
        student_details = student_map.get(student_idno, {})
        
        merged_record = record.copy()
        merged_record.update({
            'lastname': student_details.get('lastname', 'N/A'),
            'firstname': student_details.get('firstname', 'N/A'),
            'course': student_details.get('course', 'N/A'),
            'level': student_details.get('level', 'N/A')
        })
        merged_attendance.append(merged_record)
    
    return render_template("admin_attendance_log.html", 
                           attendance=merged_attendance, 
                           selected_date=selected_date,
                           message=message)


if __name__ == "__main__":
    app.run(debug=True)
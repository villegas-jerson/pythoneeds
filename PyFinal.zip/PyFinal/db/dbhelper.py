from sqlite3 import connect, Row
from datetime import datetime

database = "db/school.db"


def getprocess(sql: str, vals: list) -> list:
    conn = connect(database)
    conn.row_factory = Row
    cursor = conn.cursor()
    cursor.execute(sql, vals)
    data = cursor.fetchall()
    cursor.close()
    conn.close()
    return data


def postprocess(sql: str, vals: list) -> bool:
    try:
        conn = connect(database)
        cursor = conn.cursor()
        cursor.execute(sql, vals)
        conn.commit()
    except Exception as e:
        print(f"Error: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

    return cursor.rowcount > 0


def getall(table: str) -> list:
    sql = f"SELECT * FROM {table}"
    return getprocess(sql, [])


def getrecord(table: str, **kwargs) -> list:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())

    conditions = [f"{key}=?" for key in keys]
    condition_str = " AND ".join(conditions)

    sql = f"SELECT * FROM {table} WHERE {condition_str}"
    return getprocess(sql, vals)


def addrecord(table: str, **kwargs) -> bool:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())

    placeholders = ",".join(["?"] * len(keys))
    fields = ",".join(keys)

    sql = f"INSERT INTO {table} ({fields}) VALUES ({placeholders})"
    return postprocess(sql, vals)


def deleterecord(table: str, **kwargs) -> bool:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())

    conditions = [f"{key}=?" for key in keys]
    condition_str = " AND ".join(conditions)

    sql = f"DELETE FROM {table} WHERE {condition_str}"
    return postprocess(sql, vals)


def updaterecord(table: str, where: dict, updates: dict) -> bool:
    keys = list(updates.keys())
    vals = list(updates.values())

    set_parts = [f"{field}=?" for field in keys]
    set_clause = ", ".join(set_parts)

    where_key = list(where.keys())[0]
    where_val = list(where.values())[0]

    sql = f"UPDATE {table} SET {set_clause} WHERE {where_key} = ?"

    final_vals = vals + [where_val]
    return postprocess(sql, final_vals)

def count_records(table_name):
    """Counts the total number of records in a given table."""
    conn = connect(database)
    conn.row_factory = Row
    cursor = conn.cursor()
    
    try:
        # SQL query to count all rows
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        return count
    except Exception as e:
        print(f"Database error in count_records: {e}")
        return 0 # Return 0 on error
    finally:
        conn.close()

def count_todays_attendance(table_name="attendance"):
    """Counts the number of attendance records for the current day."""
    conn = connect(database)
    conn.row_factory = Row
    cursor = conn.cursor()
    
    # Get today's date in 'YYYY-MM-DD' format
    today_date = datetime.now().strftime("%Y-%m-%d")
    
    try:
        # SQL query to count rows where the date_time column starts with today's date string
        # This is safe for SQLite date/time format ('YYYY-MM-DD HH:MM:SS')
        query = f"SELECT COUNT(*) FROM {table_name} WHERE date_time LIKE ?"
        
        cursor.execute(query, (f"{today_date}%",))
        count = cursor.fetchone()[0]
        return count
    except Exception as e:
        print(f"Database error in count_todays_attendance: {e}")
        return 0 # Return 0 on error
    finally:
        conn.close()